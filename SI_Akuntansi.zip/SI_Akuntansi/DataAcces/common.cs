﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace DataAcces
{
    public class common
    {
        private string strConStr = @"Data Source=ASUSX550;Initial Catalog=db_SI_akuntansi;Integrated Security=True";
        //private string strConString;
        private static SqlConnection sqlCon;
        private static SqlCommand sqlCmd;
        private static SqlTransaction sqlTrans;
        //private string p;

        public bool OpenConnection()
        {
            try
            {
                sqlCon = new SqlConnection(strConStr);
                sqlCon.Open();
                sqlTrans = sqlCon.BeginTransaction();
                return true;
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message, ex);
            }

        }

        public void CloseConnection()
        {
            try
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlTrans.Commit();
                    sqlCon.Close();
                }
            }
            catch (Exception ex)
            {
                if (sqlTrans.Connection != null)
                {
                    sqlTrans.Rollback();
                }
                throw new Exception(ex.Message, ex);
            }
        }

        public bool ExecuteNonQuery(string query, List<SqlParameter> param)
        {
            try
            {
                sqlCmd = new SqlCommand(query, sqlCon, sqlTrans);
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Parameters.AddRange(param.ToArray());
                sqlCmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    if (sqlTrans.Connection != null)
                    {
                        sqlTrans.Rollback();
                    }
                    sqlCon.Close();
                }
                throw new Exception(ex.Message, ex);
            }
        }

        public bool ExecuteNonQuery(string query)
        {
            try
            {
                sqlCmd = new SqlCommand(query, sqlCon, sqlTrans);
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    if (sqlTrans.Connection != null)
                    {
                        sqlTrans.Rollback();
                    }
                    sqlCon.Close();
                }
                throw new Exception(ex.Message, ex);
            }
        }

        public static string enkrippass(string text)
        {
            return text;
        }

        public static string dekrippass(string text)
        {
            return text;
        }

        public DataTable ExecuteQuery(string query)
        {
            DataTable dt;
            SqlDataAdapter da = new SqlDataAdapter();
            try
            {
                sqlCmd = new SqlCommand(query, sqlCon, sqlTrans);
                dt = new DataTable();
                sqlCmd.CommandType = CommandType.Text;
                da.SelectCommand = sqlCmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    if (sqlTrans.Connection != null)
                    {
                        sqlTrans.Rollback();
                    }
                    sqlCon.Close();
                }
                throw new Exception(ex.Message, ex);
            }
        }

        public DataTable ExecuteQuery(string query, List<SqlParameter> param)
        {

            DataTable dt;
            SqlDataAdapter da = new SqlDataAdapter();
            try
            {
                sqlCmd = new SqlCommand(query, sqlCon, sqlTrans);
                dt = new DataTable();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandTimeout = 0;
                da.SelectCommand = sqlCmd;


                sqlCmd.Parameters.AddRange(param.ToArray());
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    if (sqlTrans.Connection != null)
                    {
                        sqlTrans.Rollback();
                    }
                    sqlCon.Close();
                }
                throw new Exception(ex.Message, ex);
            }
        }

        public DataSet ExecuteQueryDs(string query)
        {
            if (sqlCon.State == ConnectionState.Closed)
            {
                OpenConnection();
            }
            DataSet ds;
            SqlDataAdapter da = new SqlDataAdapter();
            try
            {
                sqlCmd = new SqlCommand(query, sqlCon, sqlTrans);
                ds = new DataSet();
                sqlCmd.CommandType = CommandType.Text;
                da.SelectCommand = sqlCmd;
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                if (sqlCon.State == ConnectionState.Open)
                {
                    if (sqlTrans.Connection != null)
                    {
                        sqlTrans.Rollback();
                    }
                    sqlCon.Close();
                }
                throw new Exception(ex.Message, ex);
            }
        }

        public bool executeNonQueryStoredProcedure(string spName, ArrayList spParam)
        {
            bool flag;
            try
            {
                SqlCommand command = new SqlCommand(spName, sqlCon, sqlTrans)
                {
                    CommandTimeout = 0,
                    CommandText = spName
                };
                foreach (SqlParameter parameter in spParam)
                {
                    command.Parameters.Add(new SqlParameter(parameter.ParameterName, parameter.Value));
                }
                command.CommandType = CommandType.StoredProcedure;
                command.ExecuteNonQuery();
                flag = true;
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception);
            }
            return flag;
        }

        public DataTable executeStoredProcedure(string spName, ArrayList spParam)
        {
            DataTable table2;
            try
            {
                DataTable dataTable = new DataTable("table1");

                SqlCommand command = new SqlCommand(spName, sqlCon)
                {
                    CommandTimeout = 0,
                    CommandType = CommandType.StoredProcedure
                };
                foreach (SqlParameter parameter in spParam)
                {
                    command.Parameters.Add(new SqlParameter(parameter.ParameterName, parameter.Value));
                }
                new SqlDataAdapter { SelectCommand = command }.Fill(dataTable);

                table2 = dataTable;
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message, exception);
            }
            return table2;
        }
    }
}
