﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BussinesLogic;

namespace SI_Akuntansi
{
    public partial class jurnal_pembelian : System.Web.UI.Page
    {
        CoJPembelian ctl;
        protected void Page_Load(object sender, EventArgs e)
        {
            RefreshData();
            MultiView1.SetActiveView(View1);
            rpttampil.DataSource = ctl.GetData();
            rpttampil.DataBind();
        }
        private void RefreshData()
        {
            ctl = new CoJPembelian();
            rpttampil.DataSource = ctl.GetData();
            rpttampil.DataBind();
        }

        protected void rpttampil_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "update")
            {
                DataTable dt = new DataTable();
                dt = ctl.GetData(e.CommandArgument.ToString());
                if (dt.Rows.Count > 0)
                {
                    MultiView1.SetActiveView(View2);
                    TextBox1.Enabled = false;
                    TextBox1.Text = dt.Rows[0]["tgl"].ToString();
                    TextBox2.Text = dt.Rows[0]["no_bukti"].ToString();
                    TextBox3.Text = dt.Rows[0]["keterangan"].ToString();
                    TextBox4.Text = dt.Rows[0]["pembelian"].ToString();
                    TextBox5.Text = dt.Rows[0]["potongan"].ToString();
                    btn_save.Text = "update";
                }
                else
                {
                    ShowMessage("Data Not Found");
                }
            }
            else
            {
                string c_val = Request.Form["confirm_value"];
                if (c_val == "Yes")
                {
                    Delete(e.CommandArgument.ToString());
                    RefreshData();
                    clearField();
                }
            }
        }
        private void Delete(string p)
        {
            ctl = new CoJPembelian();
            if (ctl.Delete(p))
            {
                ShowMessage("DELETE SUCCESS");
                clearField();
                RefreshData();
            }
            else
            {
                ShowMessage("Delete Failed");

            }

        }


        protected void add_Click(object sender, EventArgs e)
        {
            btn_save.Text = "Save";
            clearField();
        }

        void clearField()
        {
            tgl.Text = "";
            no_bukti.Text = "";
            jumlah.Text = "";
            ket.Text = "";
            btn_save.Text = "Save";
        }
        void ShowMessage(string message)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Alert", "alert('" + message + "');", true);
        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            ctl = new CoJPembelian();

            if (btn_save.Text == "Save")
            {

                if (ctl.Insert(tgl.Text, no_bukti.Text, ket.Text, jumlah.Text,potongan.Text, jumlah.Text))
                {
                    ShowMessage("Insert Success");
                    Response.Redirect(HttpContext.Current.Request.Url.AbsoluteUri);
                }
                else
                {
                    ShowMessage("Insert failed");
                }
            }
            else
            {
                if (ctl.Update(TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text,TextBox5.Text, TextBox4.Text))
                {
                    ShowMessage("Update Success");
                    Response.Redirect(HttpContext.Current.Request.Url.AbsoluteUri);
                }
                else
                {
                    ShowMessage("Update Failed");
                }
            }
            clearField();

            RefreshData();

        }

        protected void btn_batal_Click(object sender, EventArgs e)
        {

        }


    }
}