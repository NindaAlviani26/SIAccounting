﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BussinesLogic;

namespace SI_Akuntansi
{
    public partial class kategori : System.Web.UI.Page
    {
        CoKategori ctl;
        protected void Page_Load(object sender, EventArgs e)
        {
            RefreshData();
            MultiView1.SetActiveView(View1);
        }
        private void RefreshData()
        {
            ctl = new CoKategori();
            GridView1.DataSource = ctl.GetData();
            GridView1.DataBind();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "update")
            {
                DataTable dt = new DataTable();
                dt = ctl.GetData(e.CommandArgument.ToString());
                if (dt.Rows.Count > 0)
                {
                    MultiView1.SetActiveView(View2);
                    TextBox1.Enabled = false;
                    TextBox1.Text = dt.Rows[0]["no_kategori"].ToString();
                    TextBox2.Text = dt.Rows[0]["nama_kategori"].ToString();
                    btn_save.Text = "update";

                }
                else
                {
                    ShowMessage("Data Not Found");
                }
            }
            else
            {
                string c_val = Request.Form["confirm_value"];
                if (c_val == "Yes")
                {
                    Delete(e.CommandArgument.ToString());
                    RefreshData();
                    clearField();
                }
            }
        }
        private void Delete(string p)
        {
            ctl = new CoKategori();
            if (ctl.Delete(p))
            {
                ShowMessage("DELETE SUCCESS");
                clearField();
                RefreshData();
            }
            else
            {
                ShowMessage("Delete Failed");

            }

        }


        protected void add_Click(object sender, EventArgs e)
        {
            btn_save.Text = "Save";
            clearField();
        }
        void clearField()
        {
            no_kateg.Text = "";
            nama_kateg.Text = "";
            btn_save.Text = "Save";
        }
        void ShowMessage(string message)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Alert", "alert('" + message + "');", true);
        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            ctl = new CoKategori();
            if (btn_save.Text == "Save")
            {
                if (ctl.Insert(no_kateg.Text, nama_kateg.Text))
                {
                    ShowMessage("Insert Success");
                    Response.Redirect(HttpContext.Current.Request.Url.AbsoluteUri);//1
                    //Di akhir metode, lakukan redirect ke halaman yang sama, ini akan menghapus data POSTed.

                    //Sesuatu seperti ini:
                    // btn_save.Text = "no";
                }
                else
                {
                    ShowMessage("Insert failed");
                }
            }
            else
            {
                if (ctl.Update(TextBox1.Text, TextBox2.Text))
                {
                    ShowMessage("Update Success");
                    Response.Redirect(HttpContext.Current.Request.Url.AbsoluteUri);
                }
                else
                {
                    ShowMessage("Update Failed");
                }
            }
            clearField();

            RefreshData();

        }

        protected void btn_batal_Click(object sender, EventArgs e)
        {

        }
    }
}