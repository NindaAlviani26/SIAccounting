﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BussinesLogic;
using System.Data.SqlClient;
using System.Data;

namespace SI_Akuntansi
{
    public partial class login_user : System.Web.UI.Page
    {
        CoLogin ctl;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user"] != null)
            {
                Response.Redirect("Site.Master");
            }
        }
       
        public void masuk_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            string us;
            ctl = new CoLogin();
            try
            {
                dt = ctl.GetData(username.Text, password.Text);
                if (dt.Rows.Count > 0)
                {
                    Session["user"] = username.Text;
                    us = dt.Rows[0]["hak_akses"].ToString();
                    if (us == "Admin")
                    {
                        Response.Redirect("akun.aspx");
                    }
                    else
                    {
                        Response.Redirect("akun.aspx");

                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Username atau password salah!.');</script>");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        void ShowMessage(string message)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Alert", "alert('" + message + "');", true);
        }
    }
}