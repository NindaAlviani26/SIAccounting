﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BussinesLogic;
using System.Data.SqlClient;
using System.Data;

namespace SI_Akuntansi
{
    public partial class SignUp : System.Web.UI.Page
    {
        CoLogin ctl;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        protected void daftar(object sender, EventArgs e)
        {
            ctl = new CoLogin();
            ctl.Insert(username.Text, password.Text, DropDownAkses.Text);
            ShowMessage("anda telah suskes mendaftar");
            Response.Redirect("akun.aspx");
        }

        void ShowMessage(string message)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Alert", "alert('" + message + "');", true);
        }
    }
}