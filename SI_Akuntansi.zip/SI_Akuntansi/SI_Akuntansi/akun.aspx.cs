﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BussinesLogic;
using System.Configuration;
using System.Data.SqlClient;

namespace SI_Akuntansi
{
    public partial class akun : System.Web.UI.Page
    {
        CoAkun ctl;
        protected void Page_Load(object sender, EventArgs e)
        {
            RefreshData();
            MultiView1.SetActiveView(View1);
        }
        private void RefreshData()
        {
            ctl = new CoAkun();
            GridView1.DataSource = ctl.GetData();
            GridView1.DataBind();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "update")
            {
                DataTable dt = new DataTable();
                dt = ctl.GetData(e.CommandArgument.ToString());
                if (dt.Rows.Count > 0)
                {
                    MultiView1.SetActiveView(View2);
                    TextBox1.Enabled = false;
                    TextBox1.Text = dt.Rows[0]["no_akun"].ToString();
                    TextBox2.Text = dt.Rows[0]["nama_akun"].ToString();
                    DropDownList1.Text = dt.Rows[0]["kategori"].ToString();
                    TextBox3.Text = dt.Rows[0]["keterangan"].ToString();
                    btn_save.Text = "update";

                }
                else
                {
                    ShowMessage("Data Not Found");
                }
            }
            else
            {
                string c_val = Request.Form["confirm_value"];
                if (c_val == "Yes")
                {
                    Delete(e.CommandArgument.ToString());
                    RefreshData();
                    clearField();
                }
            }
        }
        private void Delete(string p)
        {
            ctl = new CoAkun();

            if (p != "111" || p != "212" || p != "320" || p != "411" || p != "421")
            {
                ShowMessage("Akun tidak bisa  dihapus!");
            }
            else
            {
                if (ctl.Delete(p))
                {
                    ShowMessage("DELETE SUCCESS");
                    clearField();
                    RefreshData();
                }
                else
                {
                    ShowMessage("Delete Failed");

                }
            }
        }


        protected void add_Click(object sender, EventArgs e)
        {
            btn_save.Text = "Save";
            clearField();
        }
        void clearField()
        {
            no_akun.Text = "";
            nama_akun.Text = "";
            keterangan.Text = "";
            btn_save.Text = "Save";
        }
        void ShowMessage(string message)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "Alert", "alert('" + message + "');", true);
        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            ctl = new CoAkun();
            if (btn_save.Text == "Save")
            {
                if (ctl.Insert(no_akun.Text, nama_akun.Text, DropDownAkun.SelectedItem.Text, saldo.Text, keterangan.Text))
                {
                    ShowMessage("Insert Success");
                    Response.Redirect(HttpContext.Current.Request.Url.AbsoluteUri);
                }
                else
                {
                    ShowMessage("Insert failed");
                }
            }
            else
            {
                if (ctl.Update(TextBox1.Text, TextBox2.Text, DropDownList1.SelectedItem.Text, TextBox3.Text, TextBox4.Text))
                {
                    ShowMessage("Update Success");
                    Response.Redirect(HttpContext.Current.Request.Url.AbsoluteUri);
                }
                else
                {
                    ShowMessage("Update Failed");
                }
            }
            clearField();

            RefreshData();

        }

        protected void btn_batal_Click(object sender, EventArgs e)
        {

        }
    }
}