﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAcces;

namespace BussinesLogic
{
    public class CoJPenjualan
    {
        common DA;
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [tgl]
      ,[no_bukti]
      ,[keterangan]
      ,[debet]
      ,[kredit]
  FROM [db_SI_akuntansi].[dbo].[jurnal_penjualan]
";
            DA = new common();
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query);
            DA.CloseConnection();
            return dt;
        }
        public DataTable GetData(string no_bukti)
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [tgl]
      ,[no_bukti]
      ,[keterangan]
      ,[debet]
      ,[kredit]
  FROM [db_SI_akuntansi].[dbo].[jurnal_penjualan]
  WHERE [no_bukti]=@no_bukti
";

            DA = new DataAcces.common();
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@no_bukti", no_bukti));
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query, param);
            DA.CloseConnection();
            return dt;
        }

        public bool Insert(string tgl, string no_bukti, string keterangan, string debet, string kredit)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@tgl", tgl));
                param.Add(new SqlParameter("@no_bukti", no_bukti));
                param.Add(new SqlParameter("@keterangan", keterangan));
                param.Add(new SqlParameter("@debet", debet));
                param.Add(new SqlParameter("@kredit", kredit));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"INSERT INTO [db_SI_akuntansi].[dbo].[jurnal_penjualan]
           ([tgl]
           ,[no_bukti]
           ,[keterangan]
           ,[debet]
           ,[kredit])
     VALUES
           (@tgl
           ,@no_bukti
           ,@keterangan
           ,@debet
           ,@kredit)

", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Update(string tgl, string no_bukti, string keterangan, string debet, string kredit)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>(); 
                param.Add(new SqlParameter("@tgl", tgl));
                param.Add(new SqlParameter("@no_bukti", no_bukti));
                param.Add(new SqlParameter("@keterangan", keterangan));
                param.Add(new SqlParameter("@debet", debet));
                param.Add(new SqlParameter("@kredit", kredit));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"UPDATE [db_SI_akuntansi].[dbo].[jurnal_penjualan]
   SET [tgl] = @tgl
      ,[no_bukti] = @no_bukti
      ,[keterangan] = @keterangan
      ,[debet] = @debet
      ,[kredit] = @kredit
 WHERE [no_bukti] = @no_bukti


", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool Delete(string p)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_bukti", p));
                DA.OpenConnection();
                DA.ExecuteNonQuery("DELETE FROM [db_SI_akuntansi].[dbo].[jurnal_penjualan] WHERE [no_bukti] = @no_bukti", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
