﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAcces;


namespace BussinesLogic
{
    public class CoLogin
    {
        common DA;
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = @"SELECT  [username]
      ,[password]
      ,[hak_akses]
  FROM [db_SI_akuntansi].[dbo].[logIn]
GO



";
            DA = new common();
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query);
            DA.CloseConnection();

            return dt;

        }
        public DataTable GetData(string username, string password)
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [username]
      ,[password]
      ,[hak_akses]
  FROM [db_SI_akuntansi].[dbo].[logIn]
  WHERE [username]=@username and [password]=@password
";

            DA = new DataAcces.common();

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@username", username));
            param.Add(new SqlParameter("@password", password));

            DA.OpenConnection();
            dt = DA.ExecuteQuery(query, param);
            DA.CloseConnection();

            return dt;

        }
        public bool Insert(string username, string password, string hak_akses)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@username", username));
                param.Add(new SqlParameter("@password", password));
                param.Add(new SqlParameter("@hak_akses", hak_akses));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"INSERT INTO [db_SI_akuntansi].[dbo].[logIn]
           ([username]
           ,[password]
           ,[hak_akses])
     VALUES
           (@username
           ,@password
           ,@hak_akses)



", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
