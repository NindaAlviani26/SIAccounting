﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAcces;

namespace BussinesLogic
{
    public class CoAkun
    {
        common DA;
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [no_akun]
      ,[nama_akun]
      ,[kategori]
      ,[saldo]
      ,[keterangan]
  FROM [db_SI_akuntansi].[dbo].[data_akun]
GO



";
            DA = new common();
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query);
            DA.CloseConnection();

            return dt;

        }

        public DataTable GetData(string no_akun)
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [no_akun]
      ,[nama_akun]
      ,[kategori]
      ,[saldo]
      ,[keterangan]
  FROM [db_SI_akuntansi].[dbo].[data_akun]
  WHERE [no_akun]=@no_akun
";

            DA = new DataAcces.common();
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@no_akun", no_akun));
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query, param);
            DA.CloseConnection();
            return dt;
        }

        public bool Insert(string no_akun, string nama_akun, string kategori, string saldo, string keterangan)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_akun", no_akun));
                param.Add(new SqlParameter("@nama_akun", nama_akun));
                param.Add(new SqlParameter("@kategori", kategori));
                param.Add(new SqlParameter("@saldo", saldo));
                param.Add(new SqlParameter("@keterangan", keterangan));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"INSERT INTO [db_SI_akuntansi].[dbo].[data_akun]
           ([no_akun]
           ,[nama_akun]
           ,[kategori]
           ,[saldo]
           ,[keterangan])
     VALUES
           (@no_akun
           ,@nama_akun
           ,@kategori
           ,@saldo
           ,@keterangan)
", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Update(string no_akun, string nama_akun, string kategori, string saldo, string keterangan)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_akun", no_akun));
                param.Add(new SqlParameter("@nama_akun", nama_akun));
                param.Add(new SqlParameter("@kategori", kategori));
                param.Add(new SqlParameter("@saldo", saldo));
                param.Add(new SqlParameter("@keterangan", keterangan));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"UPDATE [db_SI_akuntansi].[dbo].[data_akun]
   SET [no_akun] = @no_akun
      ,[nama_akun] = @nama_akun
      ,[kategori] = @kategori
      ,[saldo]= @saldo
      ,[keterangan] =@keterangan
 WHERE [no_akun]=@no_akun
", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Delete(string p)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_akun", p));
                DA.OpenConnection();
                DA.ExecuteNonQuery("DELETE FROM [db_SI_akuntansi].[dbo].[data_akun] WHERE [no_akun]=@no_akun", param);
                DA.CloseConnection();
                return true;
                
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
