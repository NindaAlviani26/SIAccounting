﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAcces;

namespace BussinesLogic
{
    public class CoTransaksi
    {
        common DA;
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [no_transaksi]
      ,[tgl_transaksi]
      ,[uraian]
      ,[no_akun]
      ,[jumlah]
      ,[jenis]
  FROM [db_SI_akuntansi].[dbo].[data_transaksi]
";
            DA = new common();
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query);
            DA.CloseConnection();
            return dt;
        }

        public DataTable GetData(string no_transaksi)
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [no_transaksi]
      ,[tgl_transaksi]
      ,[uraian]
      ,[no_akun]
      ,[jumlah]
      ,[jenis]
  FROM [db_SI_akuntansi].[dbo].[data_transaksi]
  WHERE [no_transaksi]=@no_transaksi
";

            DA = new DataAcces.common();
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@no_transaksi", no_transaksi));
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query, param);
            DA.CloseConnection();
            return dt;
        }

        public bool Insert(string no_transaksi, string tgl_transaksi, string uraian,string no_akun, string jumlah, string jenis)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_transaksi", no_transaksi));
                param.Add(new SqlParameter("@tgl_transaksi", tgl_transaksi));
                param.Add(new SqlParameter("@uraian", uraian));
                param.Add(new SqlParameter("@no_akun", no_akun));
                param.Add(new SqlParameter("@jumlah", jumlah));
                param.Add(new SqlParameter("@jenis", jenis));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"INSERT INTO [db_SI_akuntansi].[dbo].[data_transaksi]
           ([no_transaksi]
           ,[tgl_transaksi]
           ,[uraian]
           ,[no_akun]
           ,[jumlah]
           ,[jenis])
     VALUES
           (@no_transaksi
           ,@tgl_transaksi
           ,@uraian
           ,@no_akun
           ,@jumlah
           ,@jenis)
", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Update(string no_transaksi, string tgl_transaksi, string uraian,string no_akun, string jumlah, string jenis)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_transaksi", no_transaksi));
                param.Add(new SqlParameter("@tgl_transaksi", tgl_transaksi));
                param.Add(new SqlParameter("@uraian", uraian));
                param.Add(new SqlParameter("@no_akun", no_akun));
                param.Add(new SqlParameter("@jumlah", jumlah));
                param.Add(new SqlParameter("@jenis", jenis));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"UPDATE [db_SI_akuntansi].[dbo].[data_transaksi]
   SET [no_transaksi] = @no_transaksi
      ,[tgl_transaksi] = @tgl_transaksi
      ,[uraian] = @uraian
      ,[no_akun]=@no_akun
      ,[jumlah] = @jumlah
      ,[jenis] = @jenis
 WHERE [no_transaksi] = @no_transaksi
", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Delete(string p)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_transaksi", p));
                DA.OpenConnection();
                DA.ExecuteNonQuery("DELETE FROM [db_SI_akuntansi].[dbo].[data_transaksi]  WHERE [no_transaksi] = @no_transaksi", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
