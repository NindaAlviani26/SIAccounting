﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAcces;

namespace BussinesLogic
{
    public class CoKasKeluar
    {

        common DA;
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [tgl]
      ,[no_bukti]
      ,[keterangan]
      ,[akun]
      ,[jumlah]
      ,[kas]
  FROM [db_SI_akuntansi].[dbo].[JPengeluaranKas]

";
            DA = new common();
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query);
            DA.CloseConnection();

            return dt;

        }
        public DataTable GetData(string no_bukti)
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [tgl]
      ,[no_bukti]
      ,[keterangan]
      ,[akun]
      ,[jumlah]
      ,[kas]
  FROM [db_SI_akuntansi].[dbo].[JPengeluaranKas]
    WHERE [no_bukti]=@no_bukti
";

            DA = new DataAcces.common();
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@no_bukti", no_bukti));
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query, param);
            DA.CloseConnection();

            return dt;

        }
        public bool Insert(string tgl, string no_bukti, string keterangan, string akun, string jumlah, string kas)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@tgl", tgl));
                param.Add(new SqlParameter("@no_bukti", no_bukti));
                param.Add(new SqlParameter("@keterangan", keterangan));
                param.Add(new SqlParameter("@akun", akun));
                param.Add(new SqlParameter("@jumlah", jumlah));
                param.Add(new SqlParameter("@kas", kas));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"INSERT INTO [db_SI_akuntansi].[dbo].[JPengeluaranKas]
           ([tgl]
           ,[no_bukti]
           ,[keterangan]
           ,[akun]
           ,[jumlah]
           ,[kas])
     VALUES
           (@tgl
           ,@no_bukti
           ,@keterangan
           ,@akun
           ,@jumlah
           ,@kas)
", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Update(string tgl, string no_bukti, string keterangan, string akun, string jumlah, string kas)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@tgl", tgl));
                param.Add(new SqlParameter("@no_bukti", no_bukti));
                param.Add(new SqlParameter("@keterangan", keterangan));
                param.Add(new SqlParameter("@akun", akun));
                param.Add(new SqlParameter("@jumlah", jumlah));
                param.Add(new SqlParameter("@kas", kas));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"UPDATE [db_SI_akuntansi].[dbo].[JPengeluaranKas]
   SET [tgl] = @tgl
      ,[no_bukti] = @no_bukti
      ,[keterangan] = @keterangan
      ,[akun]= @akun
      ,[jumlah]= @jumlah
     ,[kas]= @kas
 WHERE [no_bukti] = @no_bukti


", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool Delete(string p)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_bukti", p));
                DA.OpenConnection();
                DA.ExecuteNonQuery("DELETE FROM [db_SI_akuntansi].[dbo].[JPengeluaranKas] WHERE [no_bukti] = @no_bukti", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
