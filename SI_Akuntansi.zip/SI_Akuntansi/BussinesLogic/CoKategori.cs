﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DataAcces;


namespace BussinesLogic
{
    public class CoKategori
    {

        common DA;
        public DataTable GetData()
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [no_kategori]
      ,[nama_kategori]
  FROM [db_SI_akuntansi].[dbo].[kategori]
";
            DA = new common();
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query);
            DA.CloseConnection();
            return dt;
        }

        public DataTable GetData(string no_kategori)
        {
            DataTable dt = new DataTable();
            string query = @"SELECT [no_kategori]
      ,[nama_kategori]
  FROM [db_SI_akuntansi].[dbo].[kategori]
  WHERE [no_kategori]=@no_kategori
";

            DA = new DataAcces.common();
            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@no_kategori", no_kategori));
            DA.OpenConnection();
            dt = DA.ExecuteQuery(query, param);
            DA.CloseConnection();
            return dt;
        }

        public bool Insert(string no_kategori, string nama_kategori)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_kategori", no_kategori));
                param.Add(new SqlParameter("@nama_kategori", nama_kategori));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"INSERT INTO [db_SI_akuntansi].[dbo].[kategori]
           ([no_kategori]
           ,[nama_kategori])
     VALUES
           (@no_kategori
           ,@nama_kategori)
", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Update(string no_kategori, string nama_kategori)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_kategori", no_kategori));
                param.Add(new SqlParameter("@nama_kategori", nama_kategori));
                DA.OpenConnection();
                DA.ExecuteNonQuery(@"UPDATE [db_SI_akuntansi].[dbo].[kategori]
   SET [no_kategori] = @no_kategori
      ,[nama_kategori] = @nama_kategori
 WHERE [no_kategori]=@no_kategori
", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool Delete(string p)
        {
            try
            {
                DA = new common();
                List<SqlParameter> param = new List<SqlParameter>();
                param.Add(new SqlParameter("@no_kategori", p));
                DA.OpenConnection();
                DA.ExecuteNonQuery("DELETE FROM [db_SI_akuntansi].[dbo].[kategori] WHERE [no_kategori]=@no_kategori", param);
                DA.CloseConnection();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
